import UIKit

final class MainAssembly {
    
    func configure(_ dependencies: IDependencies) {
        dependencies.moduleContainer.getMainView()
    }
    
}
