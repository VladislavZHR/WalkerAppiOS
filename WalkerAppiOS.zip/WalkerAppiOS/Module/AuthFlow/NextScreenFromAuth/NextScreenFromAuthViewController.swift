import UIKit

final class NextScreenFromAuthViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .blue
        title = "Next Screen"
    }
    
}
